package com.example.news;

import com.example.news.NewsHeadLines;

public interface SelectListener {

    void OnNewsClicked(NewsHeadLines headLines);
}
